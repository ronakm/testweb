{\rtf1\ansi\ansicpg1252\cocoartf1404\cocoasubrtf470
{\fonttbl\f0\fnil\fcharset0 Menlo-Bold;\f1\fnil\fcharset0 Menlo-Regular;\f2\fnil\fcharset0 Menlo-BoldItalic;
}
{\colortbl;\red255\green255\blue255;\red0\green0\blue109;\red82\green0\blue103;\red15\green112\blue3;
}
\margl1440\margr1440\vieww25100\viewh12980\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs24 \cf2 public class 
\f1\b0 \cf0 ArgumentParse \{\uc0\u8232     
\f0\b \cf2 public static void 
\f1\b0 \cf0 main(String args[])\{\uc0\u8232         System.
\f2\i\b \cf3 out
\f1\i0\b0 \cf0 .println(
\f0\b \cf4 "Hello"
\f1\b0 \cf0 );\uc0\u8232     \}\u8232 \}\
}